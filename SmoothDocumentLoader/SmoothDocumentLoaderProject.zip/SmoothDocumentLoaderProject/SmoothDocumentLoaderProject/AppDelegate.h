//
//  AppDelegate.h
//  SmoothDocumentLoaderProject
//
//  Created by Ravi Dixit on 16/02/12.
//  Copyright (c) 2012 QUAGNITIA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
